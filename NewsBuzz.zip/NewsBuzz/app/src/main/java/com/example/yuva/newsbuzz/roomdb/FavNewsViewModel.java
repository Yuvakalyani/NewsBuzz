package com.example.yuva.newsbuzz.roomdb;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.content.Context;

import com.example.yuva.newsbuzz.retrofit.Article;

import java.util.List;


public class FavNewsViewModel extends ViewModel {
    private FavRepository mfavrepository;
    private MutableLiveData<List<Article>> marticles;
    Context ct;

    public FavNewsViewModel(Context ct) {
        this.ct = ct;
    }

    public MutableLiveData<List<Article>> getMarticles() {
        if (marticles == null) {
            marticles = new MutableLiveData<>();
            loadData();
        }
        return marticles;
    }

    public void loadData() {
        NewsDb newsDb = NewsDb.getDataBase(ct);
        marticles.setValue(newsDb.newsDao().getalldata());
    }
}
