package com.example.yuva.newsbuzz.roomdb;


import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import com.example.yuva.newsbuzz.retrofit.Article;

@Database(entities = {Article.class}, version = 3, exportSchema = false)
public abstract class NewsDb extends RoomDatabase {
    public abstract NewsDao newsDao();

    public static NewsDb newsdb;

    public static NewsDb getDataBase(Context context) {
        if (newsdb == null) {
            newsdb = Room.databaseBuilder(context, NewsDb.class, "newsDataBase")
                    .allowMainThreadQueries().fallbackToDestructiveMigration().build();
        }
        return newsdb;
    }
}
