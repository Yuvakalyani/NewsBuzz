package com.example.yuva.newsbuzz.retrofit;


import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ServicePath {
    @GET("top-headlines")
    Call<TopHeadlines> getTopHeadlines(@Query("apiKey") String apikey, @Query("country") String country,
                                       @Query("pageSize") int pagecount, @Query("category") String category);

    @GET("top-headlines")
    Call<TopHeadlines> getEverything(@Query("apiKey") String apikey, @Query("q") String query);
}
