package com.example.yuva.newsbuzz;

import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.yuva.newsbuzz.retrofit.Article;
import com.squareup.picasso.Picasso;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolder> {
    Context ct;
    List<Article> articles;

    public MainAdapter(List<Article> articles, Context mainActivity) {
        this.articles = articles;
        this.ct = mainActivity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_main, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.title.setText(articles.get(position).getTitle());
        String image = articles.get(position).getUrlToImage();
        if (image != null)
            Picasso.with(ct).load(Uri.parse(image)).placeholder(R.drawable.placeholder_img).error(R.drawable.no_image_available).into(holder.poster);
    }

    @Override
    public int getItemCount() {
        if (articles == null)
            return 0;
        else
            return articles.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.img1)
        ImageView poster;
        @BindView(R.id.title)
        TextView title;
        @BindView(R.id.readmore)
        TextView readmore;

        public ViewHolder(final View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    articles.get(getAdapterPosition());
                    Intent i = new Intent(ct, DetailActivity.class);
                    i.putExtra(DetailActivity.INTENTKEY, articles.get(getAdapterPosition()));
                    NewsWidget.setWidget(ct, articles.get(getAdapterPosition()));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        ct.startActivity(i, ActivityOptions.makeClipRevealAnimation(itemView, 0, 0, 10, 10).toBundle());
                    } else {
                        ct.startActivity(i);
                    }
                }
            });
        }
    }
}
