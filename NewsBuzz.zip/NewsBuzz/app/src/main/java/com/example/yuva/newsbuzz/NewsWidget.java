package com.example.yuva.newsbuzz;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import com.example.yuva.newsbuzz.retrofit.Article;
import com.squareup.picasso.Picasso;

/**
 * Implementation of App Widget functionality.
 */
public class NewsWidget extends AppWidgetProvider {
    public static final String WIDGET_ACTION = "com.example.yuva.newsbuzz";
    public static final String WIDGET_INTENT_DATA = "com.example.yuva.newsbuzz.data";
    static Article Article_picture;

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager,
                                int appWidgetId) {

        CharSequence widgetText = context.getString(R.string.appwidget_text);
        // Construct the RemoteViews object
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.news_widget);
        views.setTextViewText(R.id.appwidget_text, widgetText);
        Picasso.with(context).load(Article_picture.getUrlToImage()).into(views, R.id.widget_image, new int[]{appWidgetId});
        Intent i = new Intent(context, DetailActivity.class);
        i.putExtra(DetailActivity.INTENTKEY, Article_picture);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 1, i, PendingIntent.FLAG_UPDATE_CURRENT);
        views.setOnClickPendingIntent(R.id.widget_layout, pendingIntent);

        // Instruct the widget manager to update the widget
        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        //super.onReceive(context, intent);
        final String action = intent.getAction();
        if (action.equals(WIDGET_ACTION)) {
            Article_picture = intent.getParcelableExtra(WIDGET_INTENT_DATA);
            AppWidgetManager mgr = AppWidgetManager.getInstance(context);
            ComponentName cn = new ComponentName(context, NewsWidget.class);
            updateAppWidgets(context, mgr, mgr.getAppWidgetIds(cn));
        }
    }

    private void updateAppWidgets(Context context, AppWidgetManager mgr, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, mgr, appWidgetId);
        }
    }

    @Override
    public void onEnabled(Context context) {
        // Enter relevant functionality for when the first widget is created
    }

    @Override
    public void onDisabled(Context context) {
        // Enter relevant functionality for when the last widget is disabled
    }

    public static void setWidget(Context context, Article Article_picture) {
        Intent i = new Intent(context, NewsWidget.class);
        i.setComponent(new ComponentName(context, NewsWidget.class));
        i.setAction(NewsWidget.WIDGET_ACTION);
        i.putExtra(WIDGET_INTENT_DATA, Article_picture);
        context.sendBroadcast(i);

    }
}

