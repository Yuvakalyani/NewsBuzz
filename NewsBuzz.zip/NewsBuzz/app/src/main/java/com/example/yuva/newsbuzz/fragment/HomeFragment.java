package com.example.yuva.newsbuzz.fragment;


import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.yuva.newsbuzz.MainAdapter;
import com.example.yuva.newsbuzz.R;
import com.example.yuva.newsbuzz.retrofit.Article;
import com.example.yuva.newsbuzz.roomdb.EntertainmentViewModel;
import com.example.yuva.newsbuzz.roomdb.FavRepository;
import com.example.yuva.newsbuzz.roomdb.HeadLinesNewsViewModel;
import com.example.yuva.newsbuzz.roomdb.HealthViewModel;
import com.example.yuva.newsbuzz.roomdb.ScienceViewModel;
import com.example.yuva.newsbuzz.roomdb.SportsViewModel;
import com.example.yuva.newsbuzz.roomdb.TechnologyViewModel;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {
    private SectionsPagerAdapter mSectionsPagerAdapter;
    private ViewPager mViewPager;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        mSectionsPagerAdapter = new SectionsPagerAdapter(getChildFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) view.findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        TabLayout tabLayout = (TabLayout) view.findViewById(R.id.tabs);
        mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(mViewPager));
        return view;
    }

    public static class PlaceholderFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_COUNTRY = "section_number";
        private static final String ARG_SECTION_CATEGORY = "section_category";
        private static final String ARG_SECTION_POS = "section_pos";
        RecyclerView recyclerView;

        public PlaceholderFragment() {
        }

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(String country, String category, int pos) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putString(ARG_SECTION_COUNTRY, country);
            args.putString(ARG_SECTION_CATEGORY, category);
            args.putInt(ARG_SECTION_POS, pos);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_main, container, false);
            recyclerView = rootView.findViewById(R.id.recycle1);
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
            int pos = getArguments().getInt(ARG_SECTION_POS);
            switch (pos) {
                case 0:
                    HeadLinesNewsViewModel newsViewModel = ViewModelProviders.of(getActivity(),
                            new FavRepository(getActivity().getApplication(), getArguments().getString(ARG_SECTION_COUNTRY), getArguments().getString(ARG_SECTION_CATEGORY), 20)).get(HeadLinesNewsViewModel.class);
                    newsViewModel.getMarticles().observe(getActivity(), new Observer<List<Article>>() {
                        @Override
                        public void onChanged(@Nullable List<Article> articles) {
                            recyclerView.setAdapter(new MainAdapter(articles, getContext()));
                        }
                    });
                    break;
                case 1:
                    SportsViewModel newsViewModel1 = ViewModelProviders.of(getActivity(),
                            new FavRepository(getActivity().getApplication(), getArguments().getString(ARG_SECTION_COUNTRY), getArguments().getString(ARG_SECTION_CATEGORY), 20)).get(SportsViewModel.class);
                    newsViewModel1.getMarticles().observe(getActivity(), new Observer<List<Article>>() {
                        @Override
                        public void onChanged(@Nullable List<Article> articles) {
                            recyclerView.setAdapter(new MainAdapter(articles, getContext()));
                        }
                    });
                    break;
                case 2:
                    TechnologyViewModel newsViewModel2 = ViewModelProviders.of(getActivity(),
                            new FavRepository(getActivity().getApplication(), getArguments().getString(ARG_SECTION_COUNTRY), getArguments().getString(ARG_SECTION_CATEGORY), 20)).get(TechnologyViewModel.class);
                    newsViewModel2.getMarticles().observe(getActivity(), new Observer<List<Article>>() {
                        @Override
                        public void onChanged(@Nullable List<Article> articles) {
                            recyclerView.setAdapter(new MainAdapter(articles, getContext()));
                        }
                    });
                    break;
                case 3:
                    EntertainmentViewModel newsViewModel3 = ViewModelProviders.of(getActivity(),
                            new FavRepository(getActivity().getApplication(), getArguments().getString(ARG_SECTION_COUNTRY), getArguments().getString(ARG_SECTION_CATEGORY), 20)).get(EntertainmentViewModel.class);
                    newsViewModel3.getMarticles().observe(getActivity(), new Observer<List<Article>>() {
                        @Override
                        public void onChanged(@Nullable List<Article> articles) {
                            recyclerView.setAdapter(new MainAdapter(articles, getContext()));
                        }
                    });
                    break;
                case 4:
                    ScienceViewModel newsViewModel4 = ViewModelProviders.of(getActivity(),
                            new FavRepository(getActivity().getApplication(), getArguments().getString(ARG_SECTION_COUNTRY), getArguments().getString(ARG_SECTION_CATEGORY), 20)).get(ScienceViewModel.class);
                    newsViewModel4.getMarticles().observe(getActivity(), new Observer<List<Article>>() {
                        @Override
                        public void onChanged(@Nullable List<Article> articles) {
                            recyclerView.setAdapter(new MainAdapter(articles, getContext()));
                        }
                    });
                    break;
                case 5:
                    HealthViewModel newsViewModel5 = ViewModelProviders.of(getActivity(),
                            new FavRepository(getActivity().getApplication(), getArguments().getString(ARG_SECTION_COUNTRY), getArguments().getString(ARG_SECTION_CATEGORY), 20)).get(HealthViewModel.class);
                    newsViewModel5.getMarticles().observe(getActivity(), new Observer<List<Article>>() {
                        @Override
                        public void onChanged(@Nullable List<Article> articles) {
                            recyclerView.setAdapter(new MainAdapter(articles, getContext()));
                        }
                    });
                    break;
            }
            return rootView;
        }
    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            switch (position) {
                case 0:
                    return PlaceholderFragment.newInstance("in", "business", 0);
                case 1:
                    return PlaceholderFragment.newInstance("in", "sports", 1);
                case 2:
                    return PlaceholderFragment.newInstance("in", "technology", 2);
                case 3:
                    return PlaceholderFragment.newInstance("in", "entertainment", 3);
                case 4:
                    return PlaceholderFragment.newInstance("in", "science", 4);
                case 5:
                    return PlaceholderFragment.newInstance("in", "health", 5);
                default:
                    return PlaceholderFragment.newInstance("", "", 0);
            }

        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 6;
        }
    }
}
