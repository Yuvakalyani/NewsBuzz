package com.example.yuva.newsbuzz;

import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ShareCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.yuva.newsbuzz.retrofit.Article;
import com.example.yuva.newsbuzz.roomdb.NewsDb;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.squareup.picasso.Picasso;

import butterknife.BindView;
import butterknife.ButterKnife;

public class DetailActivity extends AppCompatActivity {
    public static final String INTENTKEY = "position";
    @BindView(R.id.news_poster)
    ImageView news_poster;
    @BindView(R.id.published_date)
    TextView pub_date;
    @BindView(R.id.title)
    TextView title;
    @BindView(R.id.news_description)
    TextView news_description;
    @BindView(R.id.author)
    TextView author;
    @BindView(R.id.news_content)
    TextView news_content;
    @BindView(R.id.favorite)
    FloatingActionButton favorite;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    Article articles;
    Article article;
    String id;
    Boolean b;
    private AdView mAdView;


    //FavNewsViewModel favNewsViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        article = getIntent().getParcelableExtra(INTENTKEY);
        ButterKnife.bind(this);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
        id = article.getTitle();
        articles = NewsDb.getDataBase(this).newsDao().getdata(id);
        String img = article.getUrlToImage();
        if (img != null)
            Picasso.with(DetailActivity.this).load(Uri.parse(img)).placeholder(R.drawable.placeholder_img).error(R.drawable.no_image_available).into(news_poster);
        title.setText(article.getTitle());
        pub_date.setText(getResources().getString(R.string.published) + article.getPublishedAt());
        news_description.setText(article.getDescription());
        author.setText(article.getAuthor());
        news_content.setText(article.getContent());

        MobileAds.initialize(this, getString(R.string.ad_id));
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        favorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (b) {
                    NewsDb.getDataBase(DetailActivity.this).newsDao().DeleteData(article);
                    favorite.setImageDrawable(ContextCompat.getDrawable(DetailActivity.this, R.drawable.ic_bookmark_border_white_24dp));
                    Toast.makeText(DetailActivity.this, "BookMark Removed", Toast.LENGTH_SHORT).show();
                    b = false;
                } else {
                    NewsDb.getDataBase(DetailActivity.this).newsDao().InsertData(article);
                    favorite.setImageDrawable(ContextCompat.getDrawable(DetailActivity.this, R.drawable.ic_bookmark_white_24dp));
                    Toast.makeText(DetailActivity.this, "BookMark Added", Toast.LENGTH_SHORT).show();
                    b = true;

                }
            }
        });
        if (articles != null) {
            favorite.setImageDrawable(ContextCompat.getDrawable(DetailActivity.this, R.drawable.ic_bookmark_white_24dp));
            b = true;
        } else {
            favorite.setImageDrawable(ContextCompat.getDrawable(DetailActivity.this, R.drawable.ic_bookmark_border_white_24dp));
            b = false;
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.share) {

            Intent shareIntent = createShareForecastIntent();
            startActivity(shareIntent);

        } else if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private Intent createShareForecastIntent() {
        Intent shareIntent = ShareCompat.IntentBuilder.from(this)
                .setType("text/plain")
                .setText(article.getUrl())
                .getIntent();
        shareIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT);
        return shareIntent;
    }
}

