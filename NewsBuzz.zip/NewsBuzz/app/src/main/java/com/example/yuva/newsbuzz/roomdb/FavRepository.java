package com.example.yuva.newsbuzz.roomdb;

import android.app.Application;
import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;
import android.content.Context;
import android.support.annotation.NonNull;


public class FavRepository extends ViewModelProvider.NewInstanceFactory {
    Context ct;
    String country;
    String category;
    int pageCount;

    public FavRepository(Application application, String arg1, String arg2, int arg3) {
        ct = application;
        country = arg1;
        category = arg2;
        pageCount = arg3;
    }


    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if (modelClass == FavNewsViewModel.class)
            return (T) new FavNewsViewModel(ct);
        else if (modelClass == HeadLinesNewsViewModel.class)
            return (T) new HeadLinesNewsViewModel(ct, country, category, pageCount);
        else if (modelClass == SportsViewModel.class)
            return (T) new SportsViewModel(ct, country, category, pageCount);
        else if (modelClass == TechnologyViewModel.class)
            return (T) new TechnologyViewModel(ct, country, category, pageCount);
        else if (modelClass == EntertainmentViewModel.class)
            return (T) new EntertainmentViewModel(ct, country, category, pageCount);
        else if (modelClass == ScienceViewModel.class)
            return (T) new ScienceViewModel(ct, country, category, pageCount);
        else if (modelClass == HealthViewModel.class)
            return (T) new HealthViewModel(ct, country, category, pageCount);
        else
            return super.create(modelClass);
    }
}


























    /*private NewsDao newsDao;
    private List<Article> marticles;
    Context ct;
    String country;
    String category;
    int pageCount;

    public FavRepository(Application application, String arg1, String arg2, int arg3){
        ct=application;
        country=arg1;
        category=arg2;
        pageCount=arg3;

       *//* NewsDb db=NewsDb.getDataBase(application);
        newsDao=db.newsDao();
        marticles=newsDao.getalldata();*//*
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if(modelClass==FavNewsViewModel.class)
            return (T) new FavNewsViewModel(ct);
        else if(modelClass==HeadLinesNewsViewModel.class)
            return (T) new HeadLinesNewsViewModel(ct,country,category,pageCount);
        else if(modelClass==SportsViewModel.class)
            return (T) new SportsViewModel(ct,country,category,pageCount);
        else if(modelClass==TechnologyViewModel.class)
            return (T) new TechnologyViewModel(ct,country,category,pageCount);
        else if(modelClass==EntertainmentViewModel.class)
            return (T) new EntertainmentViewModel(ct,country,category,pageCount);
        else if(modelClass==ScienceViewModel.class)
            return (T) new ScienceViewModel(ct,country,category,pageCount);
        else if(modelClass==HealthViewModel.class)
            return (T) new HealthViewModel(ct,country,category,pageCount);

        else
            return super.create(modelClass);
    }*/
