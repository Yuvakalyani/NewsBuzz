package com.example.yuva.newsbuzz.fragment;


import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.yuva.newsbuzz.MainAdapter;
import com.example.yuva.newsbuzz.R;
import com.example.yuva.newsbuzz.retrofit.Article;
import com.example.yuva.newsbuzz.roomdb.FavNewsViewModel;
import com.example.yuva.newsbuzz.roomdb.FavRepository;
import com.example.yuva.newsbuzz.roomdb.NewsDb;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * A simple {@link Fragment} subclass.
 */
public class FavoriteFragment extends Fragment {
    NewsDb newsDb;
    Context c;
    List<Article> favs;
    private FavNewsViewModel viewModel;
    @BindView(R.id.fav_recycle)
    RecyclerView recycle1;
    @BindView(R.id.fav_error_tv)
    TextView fav_error_tv;

    public FavoriteFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_favorite, container, false);
        newsDb = NewsDb.getDataBase(getContext());
        favs = newsDb.newsDao().getalldata();
        ButterKnife.bind(this, v);
        recycle1.setLayoutManager(new LinearLayoutManager(getContext()));
        recycle1.setHasFixedSize(true);
        viewModel = ViewModelProviders.of(getActivity(), new FavRepository(getActivity().getApplication(), "", "", 0)).get(FavNewsViewModel.class);
        viewModel.getMarticles().observe(getActivity(), new Observer<List<Article>>() {
            @Override
            public void onChanged(@Nullable List<Article> articles) {
                if (articles.size() == 0) {
                    fav_error_tv.setVisibility(View.VISIBLE);
                    recycle1.setVisibility(View.GONE);
                } else {
                    fav_error_tv.setVisibility(View.GONE);
                    recycle1.setVisibility(View.VISIBLE);
                }
                recycle1.setAdapter(new MainAdapter(articles, getContext()));

            }
        });
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        FavNewsViewModel viewModel = ViewModelProviders.of(getActivity(), new FavRepository
                (getActivity().getApplication(), "", "", 0)).get(FavNewsViewModel.class);
        viewModel.loadData();
    }
}
