package com.example.yuva.newsbuzz.roomdb;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.content.Context;
import android.util.Log;

import com.example.yuva.newsbuzz.BuildConfig;
import com.example.yuva.newsbuzz.retrofit.Article;
import com.example.yuva.newsbuzz.retrofit.BaseUrl;
import com.example.yuva.newsbuzz.retrofit.ServicePath;
import com.example.yuva.newsbuzz.retrofit.TopHeadlines;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.ContentValues.TAG;

public class HeadLinesNewsViewModel extends ViewModel {
    Context c;
    public MutableLiveData<List<Article>> marticles;
    String country, category;
    int pageCount;

    public HeadLinesNewsViewModel(Context ct, String country, String category, int pageCount) {
        this.c = ct;
        this.country = country;
        this.category = category;
        this.pageCount = pageCount;
    }

    public MutableLiveData<List<Article>> getMarticles() {
        if (marticles == null) {
            marticles = new MutableLiveData<>();
            loadData();
        }
        return marticles;
    }

    public void loadData() {
        BaseUrl baseUrl = new BaseUrl();
        ServicePath servicepath = baseUrl.getRetrofit().create(ServicePath.class);
        Call<TopHeadlines> call = servicepath.getTopHeadlines(BuildConfig.Api_Key, country, 20, category);
        call.enqueue(new Callback<TopHeadlines>() {
            @Override
            public void onResponse(Call<TopHeadlines> call, Response<TopHeadlines> response) {
                marticles.setValue(response.body().getArticles());
            }

            @Override
            public void onFailure(Call<TopHeadlines> call, Throwable t) {
                Log.i(TAG, "onFailure: " + t);
            }
        });
    }
}
