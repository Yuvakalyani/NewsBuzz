package com.example.yuva.newsbuzz.roomdb;


import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.yuva.newsbuzz.retrofit.Article;

import java.util.List;

@Dao
public interface NewsDao {
    @Insert
    void InsertData(Article favoriteArticles);

    @Query("select * from favarticles where title like:id")
    Article getdata(String id);

    @Query("select * from favarticles")
    List<Article> getalldata();

    @Delete
    void DeleteData(Article favorite);
}
