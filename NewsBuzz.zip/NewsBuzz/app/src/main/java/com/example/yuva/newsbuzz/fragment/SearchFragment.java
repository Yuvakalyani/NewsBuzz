package com.example.yuva.newsbuzz.fragment;


import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.yuva.newsbuzz.BuildConfig;
import com.example.yuva.newsbuzz.MainAdapter;
import com.example.yuva.newsbuzz.R;
import com.example.yuva.newsbuzz.retrofit.Article;
import com.example.yuva.newsbuzz.retrofit.BaseUrl;
import com.example.yuva.newsbuzz.retrofit.ServicePath;
import com.example.yuva.newsbuzz.retrofit.TopHeadlines;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.support.constraint.Constraints.TAG;

/**
 * A simple {@link Fragment} subclass.
 */
public class SearchFragment extends android.support.v4.app.Fragment {
    BaseUrl baseUrl;
    ServicePath servicePath;
    List<Article> articles;
    @BindView(R.id.recycle2)
    RecyclerView recycle2;
    @BindView(R.id.keyword)
    TextInputEditText keyword;
    @BindView(R.id.text_input_layout)TextInputLayout text_input_layout;

    @BindView(R.id.searchbtn)
    Button searchbtn;
    String query;

    public SearchFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        closeKeyboard();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View v = inflater.inflate(R.layout.fragment_search, container, false);
        ButterKnife.bind(this, v);


        if (savedInstanceState != null) {
            closeKeyboard();
            articles = savedInstanceState.getParcelableArrayList("searched_data");
            if (articles.size() > 0) {
                recycle2.setVisibility(View.VISIBLE);
                recycle2.setLayoutManager(new LinearLayoutManager(getContext()));
                recycle2.setAdapter(new MainAdapter(articles, getContext()));
                recycle2.setHasFixedSize(true);
            } else {
                recycle2.setVisibility(View.GONE);
                Toast.makeText(getContext(), "Sorry!Results not found", Toast.LENGTH_SHORT).show();

            }
        }

        searchbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {
                query = keyword.getText().toString();
                //Toast.makeText(getContext(), ""+query, Toast.LENGTH_SHORT).show();
                if (query.isEmpty())
                    text_input_layout.setError("It should not be empty");
                else {
                    text_input_layout.setError(null);
                    text_input_layout.setErrorEnabled(false);
                    baseUrl = new BaseUrl();
                    servicePath = baseUrl.getRetrofit().create(ServicePath.class);
                    Call<TopHeadlines> searchcall = servicePath.getEverything(BuildConfig.Api_Key, query);
                    searchcall.enqueue(new Callback<TopHeadlines>() {
                        @Override
                        public void onResponse(Call<TopHeadlines> call, Response<TopHeadlines> response) {
                            articles = response.body().getArticles();
                            if (articles.size() > 0) {
                                recycle2.setVisibility(View.VISIBLE);
                                recycle2.setLayoutManager(new LinearLayoutManager(getContext()));
                                recycle2.setAdapter(new MainAdapter(articles, getContext()));
                                recycle2.setHasFixedSize(true);
                            } else {
                                recycle2.setVisibility(View.GONE);
                                Snackbar.make(getView(), "Sorry!No results found", Snackbar.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<TopHeadlines> call, Throwable t) {
                            Log.i(TAG, "" + t);
                        }
                    });
                    closeKeyboard();
                }
            }
        });

        return v;
    }

    private void closeKeyboard() {
        View v = getActivity().getCurrentFocus();
        if (v != null) {
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }
    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList("searched_data", (ArrayList<? extends Parcelable>) articles);
    }
}



